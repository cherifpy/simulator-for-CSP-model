import os
os.environ.setdefault("MPLBACKEND", "Agg")  # headless: gantt charts are saved to file, not shown interactively

import json
import logging
import random
import sys
import argparse
import multiprocessing
import pandas as pd


sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from simulator import (
    simulatorForOptimalPerfsUsingCSPOnline,
    generateHeterogeneousInfrastructure,
    generateHeterogeneousInfrastructureEquilibre,
    save_results_to_csv,
    configure_logging,
)

from utils.parser import ArgumentParser


from utils.plots import plot_line, plot_gantt_chart

logger = logging.getLogger(__name__)

def generateJobs(config):
    jobs= []
    for i in range(config['total_nb_jobs']):
        nb_tasks = random.randint(config['min_nb_tasks_per_job'], config['max_nb_tasks_per_job'])
        task_duration = random.uniform(config['min_task_duration_sec'], config['max_task_duration_sec'])
        dataset_size = random.uniform(config['min_dataset_size_MB'], config['max_dataset_size_MB'])
        jobs.append((nb_tasks,task_duration,dataset_size))
    return jobs


def main():

    arg_parser = ArgumentParser()
    args = arg_parser.parse()

    # Initialize logging
    configure_logging(args.log_level)

    with open(args.config, "r", encoding="utf-8") as f:
        config = json.load(f)

    processes = []
    
    """ Heterogeneous version """
    random.seed(42)
    for nb_jobs, nb_nodes in [(5,10),(10,50),(20,50),(20,100),(50,100)]:
        instance_dir = f"/Users/cherif/Documents/Traveaux/simulator-for-CSP-model/simulator/workloads/GeneratedJobs/instances-{config['lambda_rate']}/inst1-{nb_jobs}j-{nb_nodes}Nodes"
        config['jobs_file_path'] = f"{instance_dir}/jobs.json"
        results_destination = f"/Users/cherif/Documents/Traveaux/simulator-for-CSP-model/simulator/results-with-storage-contrainte/results-on-instances-{config['lambda_rate']}/inst1-{nb_jobs}j-{nb_nodes}Nodes"
        exp_name = ""

        os.makedirs(results_destination, exist_ok=True)

        config['total_nb_jobs'] = nb_jobs
        config['total_nb_compute_nodes'] = nb_nodes

        # Run the simulation
        logger.info("Simulation begins with config: %s" ,str(config))

        nodes_config = generateHeterogeneousInfrastructureEquilibre(config, path=f"{instance_dir}/infrastructure.csv")

        random.seed(42)
        results, nodes_config_ = simulatorForOptimalPerfsUsingCSPOnline(config=config, jobs=[], overlap=True, poisson=True, varying_load=False,nodes_config=nodes_config)
        save_results_to_csv(logger, results, results_destination, exp_name)

        nodes_config_save = pd.DataFrame(nodes_config)
        nodes_config_save.to_csv(f"/{results_destination}/nodes_config.csv", index=False)

        if True: # args.plot_gantt:
            gantt_path = f"{results_destination}/gantt.png"
            process = multiprocessing.Process(
                target=plot_gantt_chart,
                args=(results.events_history, config['total_nb_compute_nodes'], f'inst1-{nb_jobs}j-{nb_nodes}Nodes'),
                kwargs={'save_path': gantt_path},
            )
            processes.append(process)
            process.start()

    # Wait for all processes to finish
    for process in processes:
        process.join()
    
if __name__ == "__main__":
    main()
