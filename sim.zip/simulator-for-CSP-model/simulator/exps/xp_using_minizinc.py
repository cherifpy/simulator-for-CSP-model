import json
import logging
import random
import sys
import os
import argparse
import multiprocessing
import pandas as pd

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

from simulator import (
    simulatorForOptimalPerfsUsingCSPOnline,
    generateHeterogeneousInfrastructure,
    generateHeterogeneousInfrastructureEquilibre,
    save_results_to_csv,
    configure_logging,
)

from utils.parser import ArgumentParser


from utils.plots import plot_line, plot_gantt_chart
from utils.run_export import start_recording

logger = logging.getLogger(__name__)

def generateJobs(config):
    jobs= []
    for i in range(config['total_nb_jobs']):
        nb_tasks = random.randint(config['min_nb_tasks_per_job'], config['max_nb_tasks_per_job'])
        task_duration = random.uniform(config['min_task_duration_sec'], config['max_task_duration_sec'])
        dataset_size = random.uniform(config['min_dataset_size_MB'], config['max_dataset_size_MB'])
        jobs.append((nb_tasks,task_duration,dataset_size))
    return jobs


def main():

    arg_parser = ArgumentParser()
    args = arg_parser.parse()

    # Initialize logging
    configure_logging(args.log_level)

    with open(args.config, "r", encoding="utf-8") as f:
        config = json.load(f)

    # Run the simulation
    logger.info("Simulation begins with config: %s" ,str(config))
    processes = []
    
    """ Heterogeneous version """    
    random.seed(42)
    
    nodes_config = generateHeterogeneousInfrastructureEquilibre(config)

    config['jobs_file_path'] = f"workloads/jobs-{config['total_nb_jobs']}.json"
    results_destination = f"results/"
    exp_name = "Test-minizinc"

    nodes_config_save = pd.DataFrame(nodes_config)
    
    nodes_config_save.to_csv(f"{results_destination}/nodes_config.csv", index=False)
    
    random.seed(42)
    start_recording(results_destination, params={"exp_name": exp_name, "total_nb_jobs": config["total_nb_jobs"]}, config=config, nodes_config=nodes_config)
    
    results, nodes_config_ = simulatorForOptimalPerfsUsingCSPOnline(config=config, jobs=[], overlap=True, poisson=True, varying_load=False,nodes_config=nodes_config)
    
    save_results_to_csv(logger, results, results_destination, exp_name)
            
    nodes_config_save = pd.DataFrame(nodes_config)
    
    nodes_config_save.to_csv(f"{results_destination}/nodes_config.csv", index=False)

    if args.plot_gantt:
        process = multiprocessing.Process(target=plot_gantt_chart, args=(results.events_history,config['total_nb_compute_nodes'],f'Order {0}'))
        processes.append(process)
        process.start()

    # Wait for all processes to finish
    for process in processes:
        process.join()
    
if __name__ == "__main__":
    main()
